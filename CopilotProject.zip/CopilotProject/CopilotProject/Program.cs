using Microsoft.Extensions.Configuration;
using YourNamespace.Models;
using YourNamespace.Services;
using YourNamespace.Services;
var builder = WebApplication.CreateBuilder(args);

var mongoDBSettings = builder.Configuration.GetSection(nameof(MongoDBSettings)).Get<MongoDBSettings>();
builder.Services.AddSingleton(mongoDBSettings);

builder.Services.AddScoped<UsersService>();
builder.Services.AddScoped<PropertiesService>();
builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
